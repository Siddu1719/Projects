let tasks = [];

function addTask() {
    const title = document.getElementById('taskTitle').value;
    const priority = document.getElementById('priority').value;
    const deadline = document.getElementById('deadline').value;

    if (title && deadline) {
        tasks.push({
            title,
            priority,
            deadline
        });
        document.getElementById('taskTitle').value = '';
        document.getElementById('deadline').value = '';
        renderTasks();
    }
}

function getStatus(deadline) {
    const today = new Date().toISOString().split('T')[0];
    if (deadline < today) return 'Overdue';
    if (deadline > today) return 'Upcoming';
    return 'Today';
}

function renderTasks() {
    const statusFilter = document.getElementById('statusFilter').value;
    const priorityFilter = document.getElementById('priorityFilter').value;

    const list = document.getElementById('taskList');
    list.innerHTML = '';

    tasks.forEach((task, index) => {
        const status = getStatus(task.deadline);
        if (
            (statusFilter === 'All' || status === statusFilter) &&
            (priorityFilter === 'All' || task.priority === priorityFilter)
        ) {
            const item = document.createElement('div');
            item.className = 'task-item';

            item.innerHTML = `
        <div class="task-left">
          <strong>${task.title}</strong>
          <span class="badge">${task.priority}</span>
          <div class="task-meta">
            📅 ${task.deadline} 
            <span class="${status === 'Overdue' ? 'overdue' : 'upcoming'}"> ${status === 'Upcoming' ? 'Due in ' + daysUntil(task.deadline) + ' days' : status}</span>
          </div>
        </div>
        <div class="actions">
          <button onclick="editTask(${index})">✏️</button>
          <button onclick="deleteTask(${index})">🗑️</button>
        </div>
      `;
            list.appendChild(item);
        }
    });
}

function daysUntil(date) {
    const now = new Date();
    const then = new Date(date);
    const diff = Math.ceil((then - now) / (1000 * 60 * 60 * 24));
    return diff;
}

function deleteTask(index) {
    tasks.splice(index, 1);
    renderTasks();
}

function editTask(index) {
    const task = tasks[index];
    document.getElementById('taskTitle').value = task.title;
    document.getElementById('priority').value = task.priority;
    document.getElementById('deadline').value = task.deadline;
    deleteTask(index);
}