let a = document.getElementById("bt1")
let b = document.getElementById("bt2")
let c = document.getElementById("bt3")
let d = document.getElementById("bt4")
let e = document.getElementById("bt5")
let time = document.getElementById("timer")
let count = parseInt(time.textContent);



a.onclick = function() {
    let uniqid = setInterval(function() {
        count -= 1
        time.textContent = count;
        if (count === 0) {
            time.textContent = 0;
            clearInterval(uniqid);
        }

    }, 1000)
};
b.onclick = function() {
    let uniqid = setInterval(function() {
        count = count
        time.textContent = count;
        if (count === 0) {
            time.textContent = 0;
            clearInterval(uniqid);
        }

    }, 1000)
};

c.onclick = function() {
    let uniqid = setInterval(function() {
        time.textContent = "25:00";
        if (count === 0) {
            time.textContent = "25.00";
            clearInterval(uniqid);
        }
    }, 1000)
};